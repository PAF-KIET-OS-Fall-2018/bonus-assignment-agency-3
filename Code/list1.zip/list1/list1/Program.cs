﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace list1
{
    class Program
    {
        static void Main(string[] args)
        {
            MYLinkedList ll = new MYLinkedList();
            Console.WriteLine("Enter List Size");
            int v = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Enter Data");
            for (int i = 0; i < v; i++)
            {
                int data = Convert.ToInt16(Console.ReadLine());
                ll.Add(data);

            }
            Thread obj = new Thread(ll.print);
            obj.Start();

            Thread obj1 = new Thread(ll.sum);
            obj1.Start();
            Thread obj2 = new Thread(ll.multiply);
            obj2.Start();
            Thread obj3 = new Thread(ll.mean);
            obj3.Start();
         

        }
    }

   
}
