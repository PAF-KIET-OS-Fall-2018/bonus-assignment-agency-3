﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace list1
{
    class MYLinkedList
    {

        class Node
        {
            public int Data;
            public Node next;
        }

        public double size;
        Node head;
        Node current;
        int v;
        double me;
        double mul = 1;

        public MYLinkedList()
        {
            head = null;
            size = 0;
        }

        public void Add(int data)
        {
            size++;
            Node node = new Node();
            node.Data = data;

            if (head == null)
            {
                head = node;
                current = node;
            }

            else
            {
                current.next = node;
                current = node;
            }
        }
        
        public void print()
        {
            Console.WriteLine("list");
            Node node = head;
            while (node != null)
            {

                Console.WriteLine(node.Data);

                node = node.next;
            }
            Console.WriteLine();

        }


        public void sum()
        {

            Node node = head;
            while (node != null)
            {
                //Console.WriteLine(node.Data);


                v = (v + node.Data);
                node = node.next;
            }

            Console.WriteLine("Total list sum = ");
            Console.WriteLine(v);
            Console.WriteLine();


        }

        public void multiply()
        {

            Node node = head;
            while (node != null)
            {
                //Console.WriteLine(node.Data);

                mul = (mul * node.Data);

                node = node.next;
            }
            Console.WriteLine("Total list MULTIPLY = ");
            Console.WriteLine(mul);
            Console.WriteLine();


        }

        public void mean()
        {
            v = 0;
            Node node = head;
            while (node != null)
            {
                //Console.WriteLine(node.Data);

                v = (v + node.Data);

                node = node.next;
            }
            me = v / size;
            Console.WriteLine("Total list mean = ");
            Console.WriteLine(me);
            Console.ReadLine();

        }
       
    }
}
